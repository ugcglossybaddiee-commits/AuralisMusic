# Auralis Music — Android Studio project

This project wraps the provided Auralis Music HTML prototype in a native Android WebView and provides a Java bridge for local audio scanning and playback.

## Build an APK
1. Install Android Studio and Android SDK Platform 35.
2. Open this `AuralisMusicProject` folder in Android Studio.
3. Use JDK 17 (Android Studio's bundled JDK is suitable).
4. Allow Gradle sync to complete (internet is needed the first time to download Gradle/Android Gradle Plugin dependencies).
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK should be at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- This environment did not have Android SDK or Gradle installed, so an APK could not be compiled or device-tested here.
- Audio scan asks for the Android audio permission at runtime.
- Playback is foreground/basic MediaPlayer playback; background playback and lock-screen controls are not implemented.
- Equalizer support depends on the device's Android audio effects.

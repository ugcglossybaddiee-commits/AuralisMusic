package com.auralis.music;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.audiofx.Equalizer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;

public class MainActivity extends Activity {
    private static final int AUDIO_PERMISSION_REQUEST = 41;
    private WebView webView;
    private MediaPlayer player;
    private Equalizer equalizer;
    private long currentId = -1;
    private String currentUri = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(13,13,18));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(13,13,18));
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(13,13,18));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean hasAudioPermission() {
        String permission = Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_AUDIO : Manifest.permission.READ_EXTERNAL_STORAGE;
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }
    private void askAudioPermission() {
        String permission = Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_AUDIO : Manifest.permission.READ_EXTERNAL_STORAGE;
        requestPermissions(new String[]{permission}, AUDIO_PERMISSION_REQUEST);
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == AUDIO_PERMISSION_REQUEST && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) scanMusicInternal();
        else runJs("window.toast && window.toast('Audio permission is needed to scan music')");
    }

    private void scanMusicInternal() {
        try {
            JSONArray array = new JSONArray();
            Uri collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
            String[] projection = {MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.DURATION};
            String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
            try (Cursor cursor = getContentResolver().query(collection, projection, selection, null, MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")) {
                if (cursor != null) {
                    int idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID);
                    int titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE);
                    int artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST);
                    int albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM);
                    int nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME);
                    int durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION);
                    while (cursor.moveToNext()) {
                        long id = cursor.getLong(idCol);
                        Uri uri = ContentUris.withAppendedId(collection, id);
                        JSONObject item = new JSONObject();
                        item.put("id", String.valueOf(id)); item.put("uri", uri.toString());
                        item.put("title", cursor.getString(titleCol)); item.put("artist", cursor.getString(artistCol));
                        item.put("album", cursor.getString(albumCol)); item.put("fileName", cursor.getString(nameCol));
                        item.put("duration", cursor.getLong(durationCol) / 1000.0);
                        array.put(item);
                    }
                }
            }
            final String result = array.toString();
            runJs("window.receiveTracks(" + JSONObject.quote(result) + ")");
        } catch (Exception e) { runJs("window.toast && window.toast('Could not scan music')"); }
    }
    private void runJs(String script) { runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(script, null); }); }

    private void releasePlayer() {
        if (equalizer != null) { try { equalizer.release(); } catch (Exception ignored) {} equalizer = null; }
        if (player != null) { try { player.stop(); } catch (Exception ignored) {} try { player.release(); } catch (Exception ignored) {} player = null; }
    }
    private void playUri(String value) {
        runOnUiThread(() -> {
            try {
                releasePlayer(); currentUri = value;
                player = new MediaPlayer(); player.setAudioStreamType(AudioManager.STREAM_MUSIC);
                player.setDataSource(MainActivity.this, Uri.parse(value));
                player.setOnPreparedListener(mp -> { mp.start(); try { equalizer = new Equalizer(0, mp.getAudioSessionId()); equalizer.setEnabled(true); } catch (Exception ignored) {} });
                player.setOnErrorListener((mp, what, extra) -> { runJs("window.toast && window.toast('Unable to play this audio file')"); return true; });
                player.prepareAsync();
            } catch (Exception e) { runJs("window.toast && window.toast('Unable to open this audio file')"); }
        });
    }

    private class AndroidBridge {
        @JavascriptInterface public void scanMusic() { runOnUiThread(() -> { if (hasAudioPermission()) scanMusicInternal(); else askAudioPermission(); }); }
        @JavascriptInterface public void playTrack(String uri) { if (uri != null && !uri.isEmpty()) playUri(uri); }
        @JavascriptInterface public void togglePlayback() { runOnUiThread(() -> { if (player == null) return; if (player.isPlaying()) player.pause(); else player.start(); }); }
        @JavascriptInterface public void seekTo(double fraction) { runOnUiThread(() -> { if (player != null && player.getDuration() > 0) player.seekTo((int)(Math.max(0, Math.min(1, fraction)) * player.getDuration())); }); }
        @JavascriptInterface public String getPosition() { try { JSONObject o = new JSONObject(); o.put("position", player == null ? 0 : player.getCurrentPosition()/1000.0); o.put("duration", player == null ? 0 : player.getDuration()/1000.0); return o.toString(); } catch (Exception e) { return "{\"position\":0,\"duration\":0}"; } }
        @JavascriptInterface public void setEqualizerEnabled(boolean enabled) { try { if (equalizer != null) equalizer.setEnabled(enabled); } catch (Exception ignored) {} }
        @JavascriptInterface public void setEqualizerPreset(String preset) {
            try { if (equalizer == null) return; short n = equalizer.getNumberOfPresets(); for (short i=0; i<n; i++) { String name = equalizer.getPresetName(i); if (name != null && name.toLowerCase().contains(preset.toLowerCase().split(" ")[0])) { equalizer.usePreset(i); return; } } } catch (Exception ignored) {}
        }
    }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { releasePlayer(); if (webView != null) webView.destroy(); super.onDestroy(); }
}
